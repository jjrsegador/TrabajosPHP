<!DOCTYPE html
<html>
<head>
   <meta charset="utf-8">
   <meta name="description" content="Desarrollo en Servidor">
   <meta name="author" content="José Javier Ramírez Segador">

  <title>"UD8 Caso1"</title>

   <!-- Hoja de estilos 
   <link rel="stylesheet" type="text/css" href="../css/UD4_Tarea4_estilos.css">
   -->
   
</head>

<body>

  <!-- Definimos los links que dan acceso a la información -->
  <a href="actores.php"> Actores </a>
  <br>
  <a href="actores_episodio.php"> Actores por episodio </a>  



</body>
</html>
